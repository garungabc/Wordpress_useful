<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Pro__Single_Event_Meta' );


	class TribeEventsPro_SingleEventMeta extends Tribe__Events__Pro__Single_Event_Meta {

	}